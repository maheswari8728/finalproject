package com.library.dao;

import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

import com.library.bean.Student;
import com.library.util.DBConnection;
import com.mysql.jdbc.exceptions.jdbc4.MySQLIntegrityConstraintViolationException;


public class StudentDetailsDAOImpl implements StudentDetailsDAO {

	@Override
	public Boolean addStudentDetails(Student student) throws ClassNotFoundException, IOException, SQLException {
		Connection connection=DBConnection.getConnection();
		PreparedStatement preparedStatement=null;
		try
		{
			preparedStatement=connection.prepareStatement("insert into studentdetails values(?,?,?,?,?,?)");
			preparedStatement.setInt(1, student.getStu_id());
			preparedStatement.setInt(2,student.getBook_id());
			preparedStatement.setString(3, student.getStu_name());
			preparedStatement.setFloat(4, student.getFine());
			preparedStatement.setDate(5, new java.sql.Date(student.getIssue_date().getTime()));
			preparedStatement.setDate(6, new java.sql.Date(student.getReturn_date().getTime()));
			preparedStatement.executeUpdate();
			return true;
			
		}
		
		catch (MySQLIntegrityConstraintViolationException e) {
			return false;
	    }
		catch(SQLException ex)
		{
			throw new MySQLIntegrityConstraintViolationException();
		}
		
	}

}
