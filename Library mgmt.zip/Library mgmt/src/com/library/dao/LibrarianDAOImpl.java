package com.library.dao;

import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.library.bean.Librarian;
import com.library.util.DBConnection;
import com.mysql.jdbc.exceptions.jdbc4.MySQLIntegrityConstraintViolationException;

public class LibrarianDAOImpl implements ILibrarianDAO{

	@Override
	public Boolean addBook(Librarian librarian) throws ClassNotFoundException, IOException, SQLException {
		Connection connection=DBConnection.getConnection();
		PreparedStatement preparedStatement=null;
	
		try
		{
			preparedStatement=connection.prepareStatement("insert into libmgmt values(?,?,?,?)");
			preparedStatement.setInt(1, librarian.getBook_id());
			preparedStatement.setString(2,librarian.getBook_name());
			preparedStatement.setString(3, librarian.getBook_author());
			preparedStatement.setString(4, librarian.getDept_name());
			preparedStatement.executeUpdate();
			return true;
		}
		catch (MySQLIntegrityConstraintViolationException e) {
			return false;
	    }
		catch(SQLException ex)
		{
			throw new MySQLIntegrityConstraintViolationException();
		}
		
	}
	
	

	@Override
	public Librarian viewBookDetails(int book_id) throws SQLException, IOException {
		Librarian librarian = new Librarian();
		Connection connection=DBConnection.getConnection();
		PreparedStatement preparedStatement=null;
		 try
		    {
			 preparedStatement=connection.prepareStatement("select * from libmgmt where book_id=?");
			 preparedStatement.setInt(1, book_id);
		      ResultSet rs = preparedStatement.executeQuery();
		      if(!rs.next()) {
		    	 return null;
		     }
		     librarian.setBook_id(rs.getInt(1));
		     librarian.setBook_name(rs.getString(2));
		     librarian.setBook_author(rs.getString(3));
		     librarian.setDept_name(rs.getString(4));
		     DBConnection.closeConnection();
		    } catch (SQLException s) {
		      s.printStackTrace();
		    }
		return librarian;
	}
	
	

	@Override
	public List<Librarian> retrieveAll() throws SQLException, IOException {
		 List<Librarian> librarianList = new ArrayList<>();
		 Connection connection=DBConnection.getConnection();
			PreparedStatement preparedStatement=null;
		    try
		    {
		    	preparedStatement=connection.prepareStatement("select * from libmgmt");
			   ResultSet rs = preparedStatement.executeQuery();
		      while (rs.next())
		      {
		        Librarian librarian = new Librarian();
			     librarian.setBook_id(rs.getInt(1));
			     librarian.setBook_name(rs.getString(2));
			     librarian.setBook_author(rs.getString(3));
			     librarian.setDept_name(rs.getString(4));
			     librarianList.add(librarian);
		      }
		    }
		    catch (SQLException s) {
		      s.printStackTrace();
		    }
		    return librarianList.isEmpty()? null:librarianList;
	}
	
	
}
