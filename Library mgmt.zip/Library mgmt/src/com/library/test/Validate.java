package com.library.test;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class Validate {
	
	public boolean book_name(String book_name)
	{
		 Pattern pat=Pattern.compile("[A-Z][a-z]{2,20}");
		 Matcher mat=pat.matcher(book_name);
		 return true;
	}

}
